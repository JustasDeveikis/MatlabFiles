%clear data, figures, command window
close all
clc
clear
tic

%notes
%dipoles are oriented perpendicular to semiconductor fingers (along the direction specified in costheta)
%coordinates: x (right+ left-), y (up+ down-), z (distance to screen from source plane)

%constants of the EM wave

%speed of light (m/s)
c=3e8;
%frequency (in Hz)
f=3e12;  % 1e12 = 1 THz and 3e12 = 3 THz
%wavenumber
wn=2*pi*f/c;

%properties of the grid

%distance between active semiconductor fingers (in um). Twice the distance between
%semiconductor fingers
period=20;
%distance between adjacent dipoles (smaller number increases computing time
%and accuracy, in um)
density=5;
%total size of the grids (square grids with edge of length "length", in um)
length=100;
%distance between grids (in um)
dgrid=40;

% Choose the size of the pixel (NxM):
N = 4; % number of grids in a row
M = 4; % number of grids in a column
% In N = 2 and M = 3 case (2x3), grids in the pixel are arranged in this way:
% [1 2 3]
% [4 5 6]

% Choose the specific grids of the pixel you want to turn off or on:
% TOTAL NUMBER OF GRIDS (=NxM) HAS TO BE EQUAL TO THE NUMBER OF 'grid#' VARIABLES!
% IF YOU DON'T, THE CODE WILL CRASH OR GIVE USELESS DATA!

% 'I#' chooses the polarisation of volatage applied for every pixel (if I = 0,
% the pixel is not used, so it is more efficient to set this pixel's value to 'false'
%  to avoid useless calculations):

% Turn on all the grids with
% grid = ones(N,M);
% OR you can choose specific grids to be turned on:
grid = [1 1 1 1 
        1 1 1 1 
        1 1 1 1 
        1 1 1 1];


% Choose the direction of semicondctor fingers of each pixel:
% TOTAL NUMBER OF GRIDS HAS TO BE EQUAL TO THE NUMBER OF 'x_axis#' VARIABLES!
% x_axis = ones(N,M); % zeros --> false, ones --> true
% OR you can choose:
x_axis = [0 1 0 1
          1 0 1 0 
          0 1 0 1 
          1 0 1 0];
          
% x_axis = 0 & x_axis; % converts every value to 'false'
% if 'true' or '1', then it is parallel to x axis

% I = ones(N,M);
% OR you can choose:

%% USE THIS FOR LINEAR
% I = [1 0 1 0
%      0 1 0 1
%      1 0 1 0
%      0 1 0 1];

%% USE THIS FOR AZIMUTHAL
I = [ -1  -1  -1   1
      -1  -1   1  -1
       1  -1   1   1
      -1   1   1   1];

%% USE THIS FOR RADIAL
% I = [ 1 -1 -1 -1
%      -1  1 -1 -1
%       1  1 -1  1
%       1  1  1 -1];
%%
% I = I*(-1); % changing sign

% remove or add additional variables if needed, relate to the total number
% of pixels (NxM)

%%
%screen plane
%distance to screen (near = 5 micrometers, far = 50 mm)
%use near option to check how active grids are distributed
near=false;

if near==true 
    % more efficient area usage: while in 'near-field' - use as little area
    % as possible
    MAX = max(N,M);
    s1=1e-4; 
    s2=1.3*MAX*(length+dgrid)/140e3;% MAKE SURE SCREEN PLANE IS BIG ENOUGH TO FIT THE DEVICE!
    % by default: 1e-2 
else
    % while in 'far-field', use more area
    s1=1;
    s2=0.35;%100*MAX*(length+dgrid)/140e3;
end

%creation of the screen area
zs=50*1e-3*s1;

phi = deg2rad(-30:0.5:30);%ys=(-70:.5:70)*1e-3*s2;
theta = deg2rad(-180:3:180);%xs=(-70:.5:70)*1e-3*s2;

[PHI,THETA]=meshgrid(phi,theta);%meshgrid(ys,xs);
r=@(hx,hy,hz) sqrt((zs-hz).^2+(Y-hy).^2+(X-hx).^2);

zeroplane=zeros(size(phi*(theta)'));
Erawx=zeroplane;
Erawy=zeroplane;
Erawz=zeroplane;


% shift_x and shift_y matrixes are used to position grids on the pixel so
% they are centered about the center of the screen plane:

% For example:
%   2x3 pix.     3x2 pix.    3x3 pix.
% [ 1  2  3 ]   [ 1   2 ]   [ 1 2 3 ]
%      x        [ 3 x 4 ]   [ 4 x 6 ] the center of the 5-th grid matches with the center of the screen plane
% [ 4  5  6 ]   [ 5   6 ]   [ 7 8 9 ]
% where x is the center of the screen plane
dx = (length + dgrid)/2; % the minimal possible shift of grids (dx = dy, since they are squares)
shift_x = (-(M-1):2:(M-1))*dx;

shift_y = ((N-1):-2:-(N-1))*dx;

% Double loop to select every pixel:

for n = 1 : N % choose the n-th row
    for m = 1 : M % choose the m-th column
        
        % Big 'if':
        if grid(n,m) == true % if there is  a grid, then perform calculations
            
            if x_axis(n,m) == true
                
                for k=[-(length/2)+shift_x(m):density:(length/2)+shift_x(m)]
                    
                    Etx=zeroplane;
                    Ety=zeroplane;
                    Etz=zeroplane;
                    
                    for j=[length/2+shift_y(n):-period:-length/2+shift_y(n)]
                        %position of the dipole (j is y direction, k is x direction)
                        hx=k*1e-6;
                        hy=j*1e-6;
                        hz=0;
                        R=zs;%r(hx,hy,hz);
                        
                        costheta=cos(THETA);%(Y-hy)./R;
                        sintheta=sin(THETA);%sqrt((zs-hz).^2+(X-hx).^2)./R;
                        cosphi=cos(PHI);%(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
                        sinphi=sin(PHI);%(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
                        
                        Er=I(n,m).*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
                        Etheta=1i*wn.*I(n,m).*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
                        
                        Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
                        Ey=Er.*costheta-Etheta.*sintheta;
                        Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
                        
                        %sum all dipole contribution from the specific y coordinate
                        Etx=Etx+Ex;
                        Ety=Ety+Ey;
                        Etz=Etz+Ez;
                        
                    end
                    %sum all dipole contribution from the grid
                    Erawx=Erawx+Etx;
                    Erawy=Erawy+Ety;
                    Erawz=Erawz+Etz;
                    
                end
                
            else % when x_axis == false
                for k=[-(length/2)+shift_x(m):period:(length/2)+shift_x(m)]
                    
                    Etx=zeroplane;
                    Ety=zeroplane;
                    Etz=zeroplane;
                    
                    for j=[-length/2+shift_y(n):density:length/2+shift_y(n)]
                        %position of the dipole (j is y direction, k is x direction)
                        hx=k*1e-6;
                        hy=j*1e-6;
                        hz=0;
                        R=zs;%r(hx,hy,hz);
                        
                        costheta=cos(THETA);%(X-hx)./R;
                        sintheta=sin(THETA);%sqrt((zs-hz).^2+(Y-hy).^2)./R;
                        cosphi=cos(PHI);%(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
                        sinphi=sin(PHI);%(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
                        
                        Er=I(n,m).*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
                        Etheta=1i*wn.*I(n,m).*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
                        
                        Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
                        Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
                        Ex=Er.*costheta-Etheta.*sintheta;
                        
                        %sum all dipole contribution from the specific y coordinate
                        Etx=Etx+Ex;
                        Ety=Ety+Ey;
                        Etz=Etz+Ez;
                        
                    end
                    %sum all dipole contribution from the grid
                    Erawx=Erawx+Etx;
                    Erawy=Erawy+Ety;
                    Erawz=Erawz+Etz;
                end
            end
        end
    end
end


%absolute E field
Efx=abs(Erawx);
Efy=abs(Erawy);
Efz=abs(Erawz);

%real parts
Erealx=real(Erawx);
Erealy=real(Erawy);
Erealz=real(Erawz);

%phase angle
Epx=angle(Erawx);
Epy=angle(Erawy);
Epz=angle(Erawz);
%immediate phase of real parts of Ex and Ey
Ephase=angle(Erealx+1i*Erealy);

%Find Efield vector strength
Eabs=sqrt(Efx.^2+Efy.^2+Efz.^2);

%normalization
%Electric field
%normalisation to largest field from all directions
Enormrel=max([max(max(Efx)),max(max(Efy)),max(max(Efz))]);
%normalisation of each component
Enormx=Efx/Enormrel;
Enormy=Efy/Enormrel;
Enormz=Efz/Enormrel;
%normalisation of the vector magnitude
Enormabs=Eabs/max(max(Eabs));


xs = THETA; ys = PHI;

% polarplot3d(Enormabs);
% colormap('gray'),colorbar,shading interp;

angle = atan2(Erealx, Erealy);
polarplot3d(angle);
hmap(1:256,1) = linspace(0,1,256);
hmap(:,[2 3]) = 0.7;
huemap = hsv2rgb(hmap);
colormap(huemap),colorbar,shading interp;

view(0,90),axis tight equal;

disp('Calculation complete,')
toc