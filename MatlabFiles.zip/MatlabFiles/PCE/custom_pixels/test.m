%speed of light (m/s)
c=3e8;
%frequency (in Hz)
f=1e12;  % 1e12 = 1 THz and 3e12 = 3 THz
%wavenumber
wn=2*pi*f/c;

s1=1;
s2=0.35;

%creation of the screen area
ds=50*1e-3*s1;

ys=(-70:.5:70)*1e-3*s2;
xs=(-70:.5:70)*1e-3*s2;

[X, Y] = meshgrid(xs, ys);

Z = exp(-i*wn*((X.^2 + Y.^2)/(2*ds)));

surf(X,Y,real(Z));
colormap('gray'),colorbar,shading interp;
view(0,90),axis tight equal,