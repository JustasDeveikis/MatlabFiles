close all;
% figure 1 - plots normalised total E field and intensity
figure1 = figure(1);
set(figure(1), 'Position', [0 0 1500 800])
axes1 = subplot(1,3,[1 2]);
% subplot(4,4,[1,2,3,5,6,7,9,10,11]);
surf(xs*1e3,ys*1e3,Enormabs),colormap('gray'),colorbar,shading interp;
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)'); 
ylabel('y (mm)'); 
set(gca,'Fontsize',20);
set(gca, 'Fontname', 'Arial');


% limitEF = 10;
% xlim([-limitEF limitEF]);
% ylim([-limitEF limitEF]);



% subplot(4,4,[4,8,12])
% plot(Intabsy, ys*1e3);
% xlabel('Intensity')
% ylabel('y (mm)')
% axis([0 1.1 -70*s2 70*s2])
% grid on
% set(gca,'Fontsize',20);

% subplot(4,4,[14,15])
% plot(xs*1e3,Intabsx);
% axis([-70*s2 70*s2 0 1.1])
% xlabel('x (mm)')
% ylabel('Intensity')
% grid on
% set(gca,'Fontsize',20);


% figure 2 - plots the E vector field
% Figure 2 is relevant only when nearField = false (that is calculations are made in far field)
figure2 = figure(2);
set(figure(2), 'Position', [0 0 1500 800])
axes1 = subplot(1,3,[1 2]);

[xsize, ysize] = size(Erealx);

start = 1;
step = 1;
stop = xsize;




%% VECTOR MAP

% quiver(1e3*xs(start:step:stop),1e3*ys(start:step:stop),Erealx(start:step:stop, start:step:stop), Erealy(start:step:stop, start:step:stop), 1);
% axis equal
% xlabel('x (mm)'); 
% ylabel('y (mm)'); 
% set(gca,'Fontsize',20);
% 
% % Controlling the x and y axis limits:
% % for near field: limit = 0.5
% % for farfield: limit = 70 (if it is too large use 5)
% limit = 25;
% xlim([-limit limit]);
% ylim([-limit limit]);

%% AVERAGED VECTOR MAP
%{
Erealx2 = Erealx; Erealy2 = Erealy;  % copying variables

% Removing last row and column (to have 280)
Erealx2(:,end) = []; Erealx2(end,:) = []; 
Erealy2(:,end) = []; Erealy2(end,:) = []; 

step = 5;  % square matrix size for averaging

[Rx, Cx] = size(Erealx2);  % Erealy is the same to Erealx in size

AVGEx = zeros(Rx/step, Cx/step); AVGEy = zeros(Rx/step, Cx/step);  % initialisation of averaged matrices


% Loop for averaging
endRow = step;  % initialise variable for index of row's end

for row = 1 : step : Rx  % loop through rows
    
    endCol = step;  % initialise variable for index of column's end
    
    for col = 1 : step : Cx  % loop through columns
        
        avgEx = Erealx2(row:endRow, col:endCol);  % create matrix to be averaged
        avgValx = mean(mean(avgEx));  % calculating average value of matrix
        
        avgEy = Erealy2(row:endRow, col:endCol);  % create matrix to be averaged
        avgValy = mean(mean(avgEy));  % calculating average value of matrix
        
        rowInd = ((row-1)/step)+1; colInd = ((col-1)/step)+1;  % calculating row and column where avgVal is saved
        
        AVGEx(rowInd, colInd) = avgValx;  % saving avgVal in AVG matrix
        AVGEy(rowInd, colInd) = avgValy;  

        endCol = endCol + step;  % increment column index
    end
    
    endRow = endRow + step;  % increment row index
end

% Plotting data
quiver(1e3*xs(start:step:stop),1e3*ys(start:step:stop),AVGEx, AVGEy, 1);
axis equal
xlabel('x (mm)'); 
ylabel('y (mm)'); 
set(gca,'Fontsize',20);

% Controlling the x and y axis limits:
% for near field: limit = 0.5
% for farfield: limit = 70 (if it is too large use 5)
limit = 70;
xlim([-limit limit]);
ylim([-limit limit]);

%}

%% COLOUR MAP
ref = exp(-i*wn*(0.8875*zs))*exp(-i*wn*((X.^2 + Y.^2)/(2*zs)));
angle = atan2(Erealy./real(ref),Erealx./real(ref))+pi;

% Colormap
hmap(1:256,1) = linspace(0,1,256);
hmap(:,[2 3]) = 0.7;
huemap = hsv2rgb(hmap);

surf(1e3*xs(start:step:stop),1e3*ys(start:step:stop),angle(start:step:stop, start:step:stop));
colormap(huemap),colorbar,shading interp;
view(0,90),axis tight equal;
xlabel('x (mm)');
ylabel('y (mm)'); 

set(gca, 'Fontname', 'Arial')
set(gca,'Fontsize',20);

limit = 10;
xlim([-limit limit])
ylim([-limit limit]);


%% BEAMPROFILE DATA





