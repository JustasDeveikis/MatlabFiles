close all;
c_axis_max = 0.15;

subplot(1,2,1);
surf(z*1e3,xs*1e3,EGx),colormap('gray'),colorbar,shading interp;
view(0,90),axis tight equal,
caxis([0 c_axis_max]);
xlabel('z (mm)');
ylabel('x (mm)');  ylim([-10 10]);
title('Ex (normalised)');
set(gca,'DataAspectRatio',[1 1 1]); % scales x axis by 10 times

subplot(1,2,2);
surf(z*1e3,ys*1e3,EGy),colormap('gray'),colorbar,shading interp;
view(0,90),axis tight equal,
caxis([0 c_axis_max]);
xlabel('z (mm)');
ylabel('y (mm)'); ylim([-10 10]);
title('Ey (normalised)');
set(gca,'DataAspectRatio',[1 1 1]);