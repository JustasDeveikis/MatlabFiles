%clear data, figures, command window
close all
clc
clear
tic

%notes
%dipoles are oriented perpendicular to semiconductor fingers (along the direction specified in costheta)
%coordinates: x (right+ left-), y (up+ down-), z (distance to screen from source plane)

%constants of the EM wave

%speed of light (m/s)
c=3e8;
%frequency (in Hz)
f=3e12;
%wavenumber
wn=2*pi*f/c;


%properties of the grid

%distance between active semiconductor fingers (in um). Twice the distance between
%semiconductor fingers
period=20;
%distance between adjacent dipoles (smaller number increases computing time
%and accuracy, in um)
density=5;
%total size of the grids (square grids with edge of length "length", in um)
length=150;
%distance between grids (in um)
dgrid=20;
%distance between pixels (in um)
dpixel=50;

%screen plane
%distance to screen (near = 5 micrometers, far = 50 mm)
%use near option to check how active grids are distributed

s2=1;

start_value_z = 0.5*1e-2;
step_along_z = 0.5*1e-2; % m, the step value along the z axis
end_value_z = 5*1e-1;

z=50*1e-3*(start_value_z:step_along_z:end_value_z);

%creation of the screen area
ys=(-70:.5:70)*1e-3*s2;
xs=(-70:.5:70)*1e-3*s2;
[X,Y]=meshgrid(ys,xs);

% Creation of arrays where E field values of the beam along x and y axes
% are stored:
EGx = zeros(numel(xs), numel(z));
EGy = zeros(numel(ys), numel(z));

I = 1; % parameter, which determines polarity of voltage applied (as well as the direction of dipole moment):
% -1 - negative voltage (+x or +y direction)
%  0 - grid is turned off
% +1 - positive voltage (-x or -y direction)

% The semiconductor 'fingers' of the emitter are parallel to:
x_axis = false;

for  i = 1 : numel(z)
    
    %creation of the screen area
    zs = z(i);
    r=@(hx,hy,hz) sqrt((zs-hz).^2+(Y-hy).^2+(X-hx).^2);
    
    zeroplane=zeros(size(ys*(xs)'));
    Erawx=zeroplane;
    Erawy=zeroplane;
    Erawz=zeroplane;
    
    if x_axis == true
        
        for k=[-(length/2):density:(length/2)]
            
            Etx=zeroplane;
            Ety=zeroplane;
            Etz=zeroplane;
            
            for j=[length/2:-period:-length/2]
                %position of the dipole (j is y direction, k is x direction)
                hx=k*1e-6;
                hy=j*1e-6;
                hz=0;
                R=r(hx,hy,hz);
                
                costheta=(Y-hy)./R;
                sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
                cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
                sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
                
                Er=I.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
                Etheta=1i*wn.*I.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
                
                Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
                Ey=Er.*costheta-Etheta.*sintheta;
                Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
                
                %sum all dipole contribution from the specific y coordinate
                Etx=Etx+Ex;
                Ety=Ety+Ey;
                Etz=Etz+Ez;
                
            end
            %sum all dipole contribution from the grid
            Erawx=Erawx+Etx;
            Erawy=Erawy+Ety;
            Erawz=Erawz+Etz;
            
        end
        
    else
        
        for k=[-(length/2):period:(length/2)]
            
            Etx=zeroplane;
            Ety=zeroplane;
            Etz=zeroplane;
            
            for j=[-length/2:density:length/2]
                %position of the dipole (j is y direction, k is x direction)
                hx=k*1e-6;
                hy=j*1e-6;
                hz=0;
                R=r(hx,hy,hz);
                
                costheta=(X-hx)./R;
                sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
                cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
                sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
                
                Er=I.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
                Etheta=1i*wn.*I.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
                
                Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
                Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
                Ex=Er.*costheta-Etheta.*sintheta;
                
                %sum all dipole contribution from the specific y coordinate
                Etx=Etx+Ex;
                Ety=Ety+Ey;
                Etz=Etz+Ez;
                
            end
            %sum all dipole contribution from the grid
            Erawx=Erawx+Etx;
            Erawy=Erawy+Ety;
            Erawz=Erawz+Etz;
            
        end
    end
    
    %absolute E field
    Efx=abs(Erawx);
    Efy=abs(Erawy);
    Efz=abs(Erawz);
    
%     %real parts
    Erealx=real(Erawx);
    Erealy=real(Erawy);
    Erealz=real(Erawz);
    
    %phase angle
    Epx=angle(Erawx);
    Epy=angle(Erawy);
    Epz=angle(Erawz);
    %immediate phase of real parts of Ex and Ey
    Ephase=angle(Erealx+1i*Erealy);
    
    %Find Efield vector strength
    Eabs=sqrt(Efx.^2+Efy.^2+Efz.^2);
    
    %normalization
    %Electric field
    %normalisation to largest field from all directions
    
    Enormrel=max([max(max(Efx)),max(max(Efy)),max(max(Efz))]);
    %normalisation of each component
    Enormx=Efx/Enormrel;
    Enormy=Efy/Enormrel;
    Enormz=Efz/Enormrel;
    %normalisation of the vector magnitude
    if i == 1
        MAX = max(max(Eabs)); % max value whicch is used for normalisation
    end
    Enormabs=Eabs/MAX;%max(max(Eabs));

    Intnorm=max(horzcat(sum(Efx,1),(sum(Efx,2))',sum(Efy,1),(sum(Efy,2))',sum(Efz,1),(sum(Efz,2))'));
    %spatial distribution (cumulative intensity of a component, summing over x
    %or y coordinate)
    Intxx=sum(Efx, 1)/Intnorm;
    Intxy=sum(Efx, 2)/Intnorm;
    Intyx=sum(Efy, 1)/Intnorm;
    Intyy=sum(Efy, 2)/Intnorm;
    Intzx=sum(Efz, 1)/Intnorm;
    Intzy=sum(Efz, 2)/Intnorm;
    Intabsx=sum(Enormabs, 1)/max(horzcat(sum(Enormabs,1),(sum(Enormabs,2))'));
    Intabsy=sum(Enormabs, 2)/max(horzcat(sum(Enormabs,1),(sum(Enormabs,2))'));
    
    % Saving the values of beam intensity along x and y axes:
    K = round(sqrt(numel(Enormabs))/2);
    EGx(:,i) = Enormabs(K,:);
    EGy(:,i) = Enormabs(:,K);
    
end

disp('Calculation complete,')
toc