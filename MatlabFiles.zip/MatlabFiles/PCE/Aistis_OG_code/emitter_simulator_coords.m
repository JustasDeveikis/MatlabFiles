%clear data, figures, command window
close all
clc
clear
tic

%notes
%dipoles are oriented perpendicular to semiconductor fingers (along the direction specified in costheta)
%coordinates: x (right+ left-), y (up+ down-), z (distance to screen from source plane)

%constants of the EM wave

%speed of light (m/s)
c=3e8;
%frequency (in Hz)
f=3e11;
%wavenumber
wn=2*pi*f/c;


%properties of the grid

%distance between active semiconductor fingers (in um). Twice the distance between
%semiconductor fingers
period=20;
%distance between adjacent dipoles (smaller number increases computing time
%and accuracy, in um)
density=5;
%total size of the grids (square grids with edge of length "length", in um)
length=150;
%distance between grids (in um)
dgrid=20;
%distance between pixels (in um)
dpixel=50;

%grids start and end with active dipole (projecting E field) band rather then an
%inactive (masked) band


% grid control panel, clockwise distribution (shown below)
% 4 pixels each with 4 grids
% origin point in he middle, between all 4 pixels

% [4.4 4.1     1.4 1.1]
% [4.3 4.2     1.3 1.2]

% [3.4 3.1     2.4 2.1]
% [3.3 3.2     2.3 2.2]

%OR function - any satisfied condition turns the grids on

%grids with dipoles pointing to x-direction (fingers to y)
%generates mostly Ex
gx=false;
%grids with dipoles pointing to y-direction (fingers to x)
%generates mostly Ey
gy=false;
%2x2 preset (dpixel is considered as dgrid)
g2x2=true;
%3x3 preset (dgrid must be equal dpixel)
g3x3=false;
%4x4 preset
g4x4=false;

%individual pixel (pixel no., grid no.)
first1=gx||g3x3||g4x4||true;
first2=gy||g3x3||g4x4||false;
first3=gx||g2x2||g3x3||g4x4||true;
first4=gy||g3x3||g4x4||false;
second1=gx||g3x3||g4x4||false;
second2=gy||g4x4||false;
second3=gx||g4x4||false;
second4=gy||g2x2||g3x3||g4x4||false;
third1=gx||g2x2||g3x3||g4x4||false;
third2=gy||g4x4||false;
third3=gx||g4x4||false;
third4=gy||g4x4||false;
fourth1=gx||g3x3||g4x4||false;
fourth2=gy||g2x2||g3x3||g4x4||false;
fourth3=gx||g4x4||false;
fourth4=gy||g4x4||false;

%Intensity of each grid (first number for pixel, second for grid),
%(relative unit, can picture it as current in the Hertzian dipole equation)

%It will be useful when implementing custom linear polarization for each
%pixel and creating circular polarizations
I11=-1;
I12=-1;
I13=-1;
I14=-1;
I21=-1;
I22=-1;
I23=-1;
I24=-1;
I31=-1;
I32=-1;
I33=-1;
I34=-1;
I41=-1;
I42=-1;
I43=-1;
I44=-1;


%screen plane
%distance to screen (near = 5 micrometers, far = 50 mm)
%use near option to check how active grids are distributed
near=true;

if near==true
    s1=1e-4;
    s2=1e-2;
else
    s1=1;
    s2=1;
end
%s2 used in output_control too, take care when changing

%creation of the screen area
zs=50*1e-3*s1;
ys=(-70:.5:70)*1e-3*s2;
xs=(-70:.5:70)*1e-3*s2;
[X,Y]=meshgrid(ys,xs);
r=@(hx,hy,hz) sqrt((zs-hz).^2+(Y-hy).^2+(X-hx).^2);

zeroplane=zeros(size(ys*(xs)'));
Erawx=zeroplane;
Erawy=zeroplane;
Erawz=zeroplane;

%#ok<*NBRAK>

%first pixel

%1st pixel 1st grid
if first1 == true
    
    %comments in the 1.1 grid
    %each iteration calculates the electric field produced by a single dipole
    %on the whole screen plane, then goes through all dipoles in the grid
    
    for k=[length+dpixel/2+dgrid:period:2*length+dpixel/2+dgrid]
        
        %progress bar
        disp('Pixel 1, grid 1')
        disp(k)
        %initial E is zero
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2+dgrid:density:2*length+dpixel/2+dgrid]
            %position of the dipole (j is y direction, k is x direction)
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            %angles relative to dipole
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            %Efield generated (using Hertzian dipole formula)
            Er=I11.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I11.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            
            %conversion to cartesian coordinates
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            %sum all dipole contribution from the specific y coordinate
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        %sum all dipole contribution from the grid
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%1st pixel 2nd grid

if first2 == true
    for k=[length+dpixel/2+dgrid:density:2*length+dpixel/2+dgrid]
        
        %progress bar
        disp('Pixel 1, grid 2')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2:-period:dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I12.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I12.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%1st pixel 3rd grid

if first3 == true
    for k=[length+dpixel/2:-period:dpixel/2]
        %progress bar
        disp('Pixel 1, grid 3')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[dpixel/2:density:length+dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I13.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I13.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%1st pixel 4th grid
if first4 == true
    for k=[length+dpixel/2:-density:dpixel/2]
        
        %progress bar
        disp('Pixel 1, grid 4')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2+dgrid:period:2*length+dpixel/2+dgrid]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I14.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I14.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%second pixel
%2nd pixel, 1st grid

if second1 == true
    for k=[length+dpixel/2+dgrid:period:2*length+dpixel/2+dgrid]
        %progress bar
        disp('Pixel 2, grid 1')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dpixel/2:density:-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I21.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I21.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%2nd pixel 2nd grid

if second2 == true
    for k=[length+dpixel/2+dgrid:density:2*length+dpixel/2+dgrid]
        
        %progress bar
        disp('Pixel 2, grid 2')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dgrid-dpixel/2:-period:-2*length-dgrid-dpixel/2]
            
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I22.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I22.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%2nd pixel, 3rd grid
if second3 == true
    for k=[length+dpixel/2:-period:dpixel/2]
        %progress bar
        disp('Pixel 2, grid 3')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dgrid-dpixel/2:-density:-2*length-dgrid-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I23.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I23.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%2nd pixel, 4th grid

if second4 == true
    for k=[length+dpixel/2:-density:dpixel/2]
        
        %progress bar
        disp('Pixel 2, grid 4')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dpixel/2:period:-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I24.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I24.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%third pixel

%3rd pixel 1st grid
if third1 == true
    for k=[-length-dpixel/2:period:-dpixel/2]
        %progress bar
        disp('Pixel 3, grid 1')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dpixel/2:density:-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I31.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I31.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%3rd pixel, 2nd grid
if third2 == true
    for k=[-length-dpixel/2:density:-dpixel/2]
        
        %progress bar
        disp('Pixel 3, grid 2')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dgrid-dpixel/2:-period:-2*length-dgrid-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I32.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I32.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%3rd pixel 3rd grid
if third3 == true
    for k=[-length-dgrid-dpixel/2:-period:-2*length-dgrid-dpixel/2]
        %progress bar
        disp('Pixel 3, grid 3')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dgrid-dpixel/2:-density:-2*length-dgrid-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I33.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I33.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%3rd pixel, 4th grid
if third4 == true
    for k=[-length-dgrid-dpixel/2:-density:-2*length-dgrid-dpixel/2]
        
        %progress bar
        disp('Pixel 3, grid 4')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[-length-dpixel/2:period:-dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I34.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I34.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%fourth pixel

%4th pixel 1st grid
if fourth1 == true
    for k=[-length-dpixel/2:period:-dpixel/2]
        %progress bar
        disp('Pixel 4, grid 1')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2+dgrid:density:2*length+dpixel/2+dgrid]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I41.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I41.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%4th pixel 2nd grid

if fourth2 == true
    for k=[-length-dpixel/2:density:-dpixel/2]
        
        %progress bar
        disp('Pixel 4, grid 2')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2:-period:dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I42.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I42.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%4th pixel 3rd grid
if fourth3 == true
    for k=[-length-dgrid-dpixel/2:-period:-2*length-dgrid-dpixel/2]
        %progress bar
        disp('Pixel 4, grid 3')
        disp(k)
        
        %if mod(n,2)==0
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2:-density:dpixel/2]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(X-hx)./R;
            sintheta=sqrt((zs-hz).^2+(Y-hy).^2)./R;
            cosphi=(zs-hz)./sqrt((zs-hz).^2+(Y-hy).^2);
            sinphi=(Y-hy)./sqrt((zs-hz).^2+(Y-hy).^2);
            
            Er=I43.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I43.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*cosphi+Etheta.*costheta.*cosphi;
            Ey=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ex=Er.*costheta-Etheta.*sintheta;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
        
    end
end

%4th pixel 4th grid
if fourth4 == true
    for k=[-length-dgrid-dpixel/2:-density:-2*length-dgrid-dpixel/2]
        
        %progress bar
        disp('Pixel 4, grid 4')
        disp(k)
        
        Etx=zeroplane;
        Ety=zeroplane;
        Etz=zeroplane;
        
        for j=[length+dpixel/2+dgrid:period:2*length+dpixel/2+dgrid]
            hx=k*1e-6;
            hy=j*1e-6;
            hz=0;
            R=r(hx,hy,hz);
            costheta=(Y-hy)./R;
            sintheta=sqrt((zs-hz).^2+(X-hx).^2)./R;
            cosphi=(X-hx)./sqrt((zs-hz).^2+(X-hx).^2);
            sinphi=(zs-hz)./sqrt((zs-hz).^2+(X-hx).^2);
            
            Er=I44.*costheta./(2*pi*R.^2.).*(1+1./(1i*wn.*R)).*exp(-1i*wn.*R);
            Etheta=1i*wn.*I44.*sintheta./(4*pi*R).*(1+1./(1i*wn.*R)+1./(1i*wn.*R).^2).*exp(-1i*wn.*R);
            Ez=Er.*sintheta.*sinphi+Etheta.*costheta.*sinphi;
            Ey=Er.*costheta-Etheta.*sintheta;
            Ex=Er.*cosphi.*sintheta-Etheta.*costheta.*cosphi;
            
            Etx=Etx+Ex;
            Ety=Ety+Ey;
            Etz=Etz+Ez;
            
        end
        Erawx=Erawx+Etx;
        Erawy=Erawy+Ety;
        Erawz=Erawz+Etz;
    end
end

%absolute E field
Efx=abs(Erawx);
Efy=abs(Erawy);
Efz=abs(Erawz);

%real parts
Erealx=real(Erawx);
Erealy=real(Erawy);
Erealz=real(Erawz);

nreal = max([max(max(Erealx)), max(max(Erealy)), max(max(Erealz))]); % value used for normalising Erealx, Erealy and Erealz
% normalised real parts:
Enrealx = Erealx/nreal;
Enrealy = Erealy/nreal;
Enrealz = Erealz/nreal;

% Parameters for colorbar:
cmin = min([min(min(Enrealx)), min(min(Enrealy)), min(min(Enrealz))]);
cmax = max([max(max(Enrealx)), max(max(Enrealy)), max(max(Enrealz))]);

%phase angle
Epx=angle(Erawx);
Epy=angle(Erawy);
Epz=angle(Erawz);
%immediate phase of real parts of Ex and Ey
Ephase=angle(Erealx+1i*Erealy);

%Find Efield vector strength
Eabs=sqrt(Efx.^2+Efy.^2+Efz.^2);

%normalization
%Electric field
%normalisation to largest field from all directions
Enormrel=max([max(max(Efx)),max(max(Efy)),max(max(Efz))]);
%normalisation of each component
Enormx=Efx/Enormrel;
Enormy=Efy/Enormrel;
Enormz=Efz/Enormrel;
%normalisation of the vector magnitude
Enormabs=Eabs/max(max(Eabs));


%Cumulative intensity of Efield over x or y coordinate:

%normalisation to largest cumulative Efield strength
Intnorm=max(horzcat(sum(Efx,1),(sum(Efx,2))',sum(Efy,1),(sum(Efy,2))',sum(Efz,1),(sum(Efz,2))'));
%spatial distribution (cumulative intensity of a component, summing over x
%or y coordinate)
Intxx=sum(Efx, 1)/Intnorm;
Intxy=sum(Efx, 2)/Intnorm;
Intyx=sum(Efy, 1)/Intnorm;
Intyy=sum(Efy, 2)/Intnorm;
Intzx=sum(Efz, 1)/Intnorm;
Intzy=sum(Efz, 2)/Intnorm;
Intabsx=sum(Enormabs, 1)/max(horzcat(sum(Enormabs,1),(sum(Enormabs,2))'));
Intabsy=sum(Enormabs, 2)/max(horzcat(sum(Enormabs,1),(sum(Enormabs,2))'));

disp('Calculation complete,')
toc