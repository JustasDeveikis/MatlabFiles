close all;
K = round(numel(xs)/2); % the index of the middle element of array - used for intensity plots

% Comparison between Eabs and sqrt(Erealx^2 + Erealy^2 + Erealz^2)
figure1 = figure(1);
set(figure(1), 'Position', [0 0 1500 800]);
subplot(1,2,1);
surf(xs*1e3,ys*1e3,Enormabs);
colormap('gray'), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabs');

subplot(1,2,2);
surf(xs*1e3,ys*1e3,sqrt(Enrealx.^2+Enrealy.^2+Enrealz.^2));
colormap('gray'), colorbar, shading interp;
view(0,90);
axis tight equal;
% caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('sqrt(Erealx^2+Ereal^2+Erealz^2)');

% Comparison between vector plot and sqrt(Erealx^2 + Erealy^2 + Erealz^2)
figure2 = figure(2);
set(figure(2), 'Position', [0 0 1500 800])
axes1 = subplot(1,2,1);

sv = 10; % step value
Eredrealx = Erealx(1:sv:280, 1:sv:280);
Eredrealy = Erealy(1:sv:280, 1:sv:280);

xsred = xs(1:sv:280);
ysred = ys(1:sv:280);

quiver(xs*1e3,ys*1e3,Erealx,Erealy);
% quiver(xsred*1e3,ysred*1e3,Eredrealx,Eredrealy); % reduced number of
% arrows - doesn't work
axis tight equal
view(0, 90)
xlabel('x (mm)'); 
ylabel('y (mm)');
title('Vector map');

subplot(1,2,2);
surf(xs*1e3,ys*1e3,sqrt(Enrealx.^2+Enrealy.^2+Enrealz.^2));
colormap('gray'), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('sqrt(Erealx^2+Ereal^2+Erealz^2)');


% Comparison between Eabsx (Enormx), Eabsy (Enormy) and Eabsz(Enormz)
figure3 = figure(3);
set(figure(3), 'Position', [0 0 1500 800]);

subplot(2,6,[1,2]);
surf(xs*1e3,ys*1e3,Enormx);
colormap(b2r(0,1)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabsx');

subplot(2,6,[3,4]);
surf(xs*1e3,ys*1e3,Enormy);
colormap(b2r(0,1)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabsy');

subplot(2,6,[5,6]);
surf(xs*1e3,ys*1e3,Enormz);
colormap(b2r(0,1)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabsz');

% Intensity Ix = Eabsx^2 slice in the middle along x axis
subplot(2,6,[7]);
plot(xs*1e3, Enormx(K,:).^2);
xlabel('x (mm)');
ylabel('Ix');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Ix = Eabsx^2 along x axis');

% Intensity Ix = Eabsx^2 slice in the middle along y axis
subplot(2,6,[8]);
plot(xs*1e3, Enormx(:,K).^2);
xlabel('y (mm)');
ylabel('Ix');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Ix = Eabsx^2 along y axis');

% Intensity Iy = Eabsy^2 slice in the middle along x axis
subplot(2,6,[9]);
plot(xs*1e3, Enormy(K,:).^2);
xlabel('x (mm)');
ylabel('Iy');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iy = Eabsy^2 along x axis');

% Intensity Iy = Eabsy^2 slice in the middle along y axis
subplot(2,6,[10]);
plot(xs*1e3, Enormy(:,K).^2);
xlabel('y (mm)');
ylabel('Iy');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iy = Eabsy^2 along y axis');

% Intensity Iz = Eabsz^2 slice in the middle along x axis
subplot(2,6,[11]);
plot(xs*1e3, Enormz(K,:).^2);
xlabel('x (mm)');
ylabel('Iz');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iz = Eabsz^2 along x axis');

% Intensity Iz = Eabsz^2 slice in the middle along y axis
subplot(2,6,[12]);
plot(xs*1e3, Enormz(:,K).^2);
xlabel('y (mm)');
ylabel('Iz');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iz = Eabsz^2 along y axis');

% Comparison between Erealx, Erealy and Erealz
figure4 = figure(4);
set(figure(4), 'Position', [0 0 1500 800]);

subplot(2,6,[1,2]);
surf(xs*1e3,ys*1e3,Enrealx);
colormap(b2r(cmin,cmax)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([cmin cmax]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Erealx');

subplot(2,6,[3,4]);
surf(xs*1e3,ys*1e3,Enrealy);
colormap(b2r(cmin,cmax)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([cmin cmax]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Erealy');

subplot(2,6,[5,6]);
surf(xs*1e3,ys*1e3,Enrealz);
colormap(b2r(cmin,cmax)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([cmin cmax]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Erealz');

% Intensity Ix = Eabsx^2 slice in the middle along x axis
subplot(2,6,[7]);
plot(xs*1e3, Enrealx(K,:).^2);
xlabel('x (mm)');
ylabel('Ix');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Ix = Erealx^2 along x axis');

% Intensity Ix = Erealx^2 slice in the middle along y axis
subplot(2,6,[8]);
plot(xs*1e3, Enrealx(:,K).^2);
xlabel('y (mm)');
ylabel('Ix');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Ix = Erealx^2 along y axis');

% Intensity Iy = Erealy^2 slice in the middle along x axis
subplot(2,6,[9]);
plot(xs*1e3, Enrealy(K,:).^2);
xlabel('x (mm)');
ylabel('Iy');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iy = Erealy^2 along x axis');

% Intensity Iy = Erealy^2 slice in the middle along y axis
subplot(2,6,[10]);
plot(xs*1e3, Enrealy(:,K).^2);
xlabel('y (mm)');
ylabel('Iy');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iy = Erealy^2 along y axis');

% Intensity Iz = Erealz^2 slice in the middle along x axis
subplot(2,6,[11]);
plot(xs*1e3, Enrealz(K,:).^2);
xlabel('x (mm)');
ylabel('Iz');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iz = Erealz^2 along x axis');

% Intensity Iz = Erealz^2 slice in the middle along y axis
subplot(2,6,[12]);
plot(xs*1e3, Enrealz(:,K).^2);
xlabel('y (mm)');
ylabel('Iz');
grid on
axis([-70*s2 70*s2 -0.1 1.1])
title('Iz = Erealz^2 along y axis');

% Attempt to fix the vector map (?)
% Using Enormx and Enormy instead of Erealx and Erealy
% and using only every sv-th value of the array
figure5 = figure(5);
set(figure(5), 'Position', [0 0 1500 800]);

subplot(3,3,[1,2,4,5,7,8]);
% reducing number of arrows showed in the vetor plot:
sv = 10; % 'sv' stands for 'step value' and means every sv-th value is used to plot an arrow in the vector plot
Eredx = Enormx(1:sv:280, 1:sv:280);
Eredy = Enormy(1:sv:280, 1:sv:280);
Eredz = Enormz(1:sv:280, 1:sv:280);

quiver(xsred*1e3,ysred*1e3,Eredx,Eredy);
axis tight equal
view(0, 90)
xlabel('x (mm)'); 
ylabel('y (mm)');
title('Fixed vector map(?)');

% Additional subplots for Eabsx, Eabsy and Eabsz:
subplot(3,3,[3])
surf(xs*1e3,ys*1e3,Enormx);
colormap(b2r(0,1)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabsx');

subplot(3,3,[6]);
surf(xs*1e3,ys*1e3,Enormy);
colormap(b2r(0,1)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabsy');

subplot(3,3,[9]);
surf(xs*1e3,ys*1e3,Enormz);
colormap(b2r(0,1)), colorbar, shading interp;
view(0,90);
axis tight equal;
caxis([0 1]);
xlabel('x (mm)');
ylabel('y (mm)');
title('Eabsz');

