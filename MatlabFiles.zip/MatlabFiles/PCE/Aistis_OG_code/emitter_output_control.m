close all

%figures 1,2,3 display absolute electric field strength of x,y,z components,
%normalized to the largest component.
%side curves shown the cumulative intensity of the Efield over the x or y
%coordinate.
%figures 1,2,3 also have a phase map
%figure 4 displays the vector magnitude
%figure 5 displays Ex and Ey real part plane vector, and the real phase (colormap)

%figure 1  -  Ex distribution on the screen plane
figure1 = figure(1);
set(figure(1), 'Position', [0 0 1500 800])
axes1 = subplot(4,7,[1,2,3,8,9,10,15,16,17]);
surf(xs*1e3,ys*1e3,Enormx),shading interp;
colormap(axes1, 'gray')
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')
set(gca,'Fontsize',20);
%}
%
% Phase map:
axes2 = subplot(4,7,[7,5,6,14,12,13,21,19,20]);
surf(xs*1e3,ys*1e3,Epx),shading interp;
colormap(axes2, 'bone')
view(0,90),axis tight equal,
caxis([-pi pi])
set(gca,'Fontsize',20);
%}

% Intensity plot:
subplot(4,7,[4,11,18])
plot(Intxy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])
set(gca,'Fontsize',20);

% Intensity plot:
subplot(4,7,[22,23,24])
plot(xs*1e3,Intxx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')
set(gca,'Fontsize',20);

%figure 2  -  Ey distribution on the screen plane
figure2 = figure(2);
set(figure(2), 'Position', [0 0 1500 800])
axes1 = subplot(4,7,[1,2,3,8,9,10,15,16,17]);
surf(xs*1e3,ys*1e3,Enormy),shading interp;
colormap(axes1, 'gray')
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')
set(gca,'Fontsize',20);

axes2 = subplot(4,7,[7,5,6,14,12,13,21,19,20]);
surf(xs*1e3,ys*1e3,Epy),shading interp;
colormap(axes2, 'bone')
view(0,90),axis tight equal,
caxis([-pi pi])
set(gca,'Fontsize',20);

subplot(4,7,[4,11,18])
plot(Intyy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])
set(gca,'Fontsize',20);

subplot(4,7,[22,23,24])
plot(xs*1e3,Intyx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')
set(gca,'Fontsize',20);

%figure 3  -  Ez distribution on the screen plane
figure3 = figure(3);
set(figure(3), 'Position', [0 0 1500 800])
axes1 = subplot(4,7,[1,2,3,8,9,10,15,16,17]);
surf(xs*1e3,ys*1e3,Enormz),shading interp;
colormap(axes1, 'gray')
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')
set(gca,'Fontsize',20);

axes2 = subplot(4,7,[7,5,6,14,12,13,21,19,20]);
surf(xs*1e3,ys*1e3,Epz),shading interp;
colormap(axes2, 'bone')
view(0,90),axis tight equal,
caxis([-pi pi])
set(gca,'Fontsize',20);

subplot(4,7,[4,11,18])
plot(Intzy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])
set(gca,'Fontsize',20);

subplot(4,7,[22,23,24])
plot(xs*1e3,Intzx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')
set(gca,'Fontsize',20);

%figure 4  -  Etot distribution on the screen plane
figure4 = figure(4);
set(figure(4), 'Position', [0 0 1500 800])
subplot(4,4,[1,2,3,5,6,7,9,10,11]);
surf(xs*1e3,ys*1e3,Enormabs),colormap('gray'),colorbar,shading interp;
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')
set(gca,'Fontsize',20);

subplot(4,4,[4,8,12])
plot(Intabsy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])
set(gca,'Fontsize',20);

subplot(4,4,[14,15])
plot(xs*1e3,Intabsx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')
set(gca,'Fontsize',20);

%figure 5  -  vector plot

% reducing the number of arrows in vector plot:
K = round(numel(xs)/2); % the index of the middle element of array

Eredx=Erealx((K-15):(K+15), (K-15):(K+15)); % the elements from the middle of array are chosen
Eredy=Erealy((K-15):(K+15), (K-15):(K+15));

xq=xs((K-15):(K+15)); % x and y axes are modified aswell
yq=ys((K-15):(K+15));

figure5 = figure(5);
set(figure(5), 'Position', [0 0 1500 800])
axes1 = subplot(1,3,[1 2]);
z = zeros(size(Erealx));
quiver3(xq*1e3,yq*1e3,z,Erealx,Erealy,Erealz);% old vector map uses Erealx,Erealy)
axis equal
view(0, 90)
xlim([-0.5, 0.5])
ylim([-0.5, 0.5])
xlabel('x (mm)'); 
ylabel('y (mm)'); 

set(gca,'Fontsize',20);

% Controlling the x and y axis limits:
xlim([-8 8]);
ylim([-8 8]);

axes2 = subplot(1,3,3);
surf(xs*1e3,ys*1e3,Ephase),shading interp,colormap('jet'),colorbar;
view(0,90),axis tight equal,
caxis([-pi pi])
set(gca,'Fontsize',20);

%figure 6
figure6 = figure(6);
set(figure(6), 'Position', [0 0 1500 800])
set(gca,'Fontsize',20);

subplot(2,4,[1,2])
plot(ys*1e3, Intxy);
ylabel('Ex Intensity')
xlabel('y (mm)')
axis([-70*s2 70*s2 0 1.1])
set(gca,'Fontsize',20);

subplot(2,4,[5,6])
plot(xs*1e3,Intxx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Ex Intensity')
set(gca,'Fontsize',20);

subplot(2,4,[3,4])
plot(ys*1e3, Intzy);
ylabel('Ez Intensity')
xlabel('y (mm)')
axis([-70*s2 70*s2 0 1.1])
set(gca,'Fontsize',20);

subplot(2,4,[7,8])
plot(xs*1e3,Intzx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Ez Intensity')
set(gca,'Fontsize',20);
%saving the figures
%
if near == true
    d = "5um ";
else
    d = "50mm ";
end

f0=f*10^-12;

%naming the figures
title1= ""+d+f0+"THz Ex.png";
title2= ""+d+f0+"THz Ey.png";
title3= ""+d+f0+"THz Ez.png";
title4= ""+d+f0+"THz Etot.png";
title5= ""+d+f0+"THz Vector.png";
title6= ""+d+f0+"THz Uniformity.png";


% saveas(figure1, title1)
% saveas(figure2, title2)
% saveas(figure3, title3)
% saveas(figure4, title4)
% saveas(figure5, title5)
% saveas(figure6, title6)
%}

%saving the complex variables (Efield strength of real and imaginary parts
%for each component
%{
save('Ex.mat','Erawx');
save('Ey.mat','Erawy');
save('Ez.mat','Erawz');
%}

%unused code:
%
%attemt to create a vector field of x and y components
%figure 5

%reduce data to 28x28 from 281x281 for better E vector map 

%{
Eredx=Erealx(1:280,1:280);
Eredy=Erealy(1:280,1:280);
Eshapex=reshape(Eredx,10,10,784);
Earrowx=reshape(mean(mean(Eshapex)),[28,28]);
Eshapey=reshape(Eredy,10,10,784);
Earrowy=reshape(mean(mean(Eshapey)),[28,28]);

xq=(-70:5:65);
yq=(-70:5:65);
%}


%{
%attempt to create a better colormap for phase map
%where theta=0 and theta= 2pi have the same colour
red=(horzcat(linspace(0,1,64), linspace(1,0,64)))';
blue=(horzcat(linspace(1,0,64), linspace(0,1,64)))';
green=(horzcat(linspace(0,0,64), linspace(0,0,64)))';
polarmap = [red, blue, green];
%}
%}
