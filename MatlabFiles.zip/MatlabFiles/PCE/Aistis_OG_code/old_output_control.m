close all

%figures 1,2,3 display absolute electric field strength of x,y,z components,
%normalized to the largest component.
%side curves shown the cumulative intensity of the Efield over the x or y
%coordinate.
%figures 1,2,3 also have a phase map
%figure 4 displays the vector magnitude
%figure 5 displays Ex and Ey real part plane vector, and the real phase (colormap)

%figure 1
figure1 = figure(1);
set(figure(1), 'Position', [0 0 1500 800])
axes1 = subplot(4,7,[1,2,3,8,9,10,15,16,17]);
surf(xs*1e3,ys*1e3,Enormx),shading interp;
colormap(axes1, 'gray')
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')
%}
%
axes2 = subplot(4,7,[7,5,6,14,12,13,21,19,20]);
surf(xs*1e3,ys*1e3,Epx),shading interp;
colormap(axes2, 'bone')
view(0,90),axis tight equal,
caxis([-pi pi])
%}

subplot(4,7,[4,11,18])
plot(Intxy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])

subplot(4,7,[22,23,24])
plot(xs*1e3,Intxx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')

%figure 2
figure2 = figure(2);
set(figure(2), 'Position', [0 0 1500 800])
axes1 = subplot(4,7,[1,2,3,8,9,10,15,16,17]);
surf(xs*1e3,ys*1e3,Enormy),shading interp;
colormap(axes1, 'gray')
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')

axes2 = subplot(4,7,[7,5,6,14,12,13,21,19,20]);
surf(xs*1e3,ys*1e3,Epy),shading interp;
colormap(axes2, 'bone')
view(0,90),axis tight equal,
caxis([-pi pi])

subplot(4,7,[4,11,18])
plot(Intyy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])

subplot(4,7,[22,23,24])
plot(xs*1e3,Intyx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')

%figure 3
figure3 = figure(3);
set(figure(3), 'Position', [0 0 1500 800])
axes1 = subplot(4,7,[1,2,3,8,9,10,15,16,17]);
surf(xs*1e3,ys*1e3,Enormz),shading interp;
colormap(axes1, 'gray')
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')

axes2 = subplot(4,7,[7,5,6,14,12,13,21,19,20]);
surf(xs*1e3,ys*1e3,Epz),shading interp;
colormap(axes2, 'bone')
view(0,90),axis tight equal,
caxis([-pi pi])

subplot(4,7,[4,11,18])
plot(Intzy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])

subplot(4,7,[22,23,24])
plot(xs*1e3,Intzx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')

%figure 4
figure4 = figure(4);
set(figure(4), 'Position', [0 0 1500 800])
subplot(4,4,[1,2,3,5,6,7,9,10,11]);
surf(xs*1e3,ys*1e3,Enormabs),colormap('gray'),colorbar,shading interp;
view(0,90),axis tight equal,
caxis([0 1])
xlabel('x (mm)')
ylabel('y (mm)')

subplot(4,4,[4,8,12])
plot(Intabsy, ys*1e3);
xlabel('Intensity')
ylabel('y (mm)')
axis([0 1.1 -70*s2 70*s2])

subplot(4,4,[14,15])
plot(xs*1e3,Intabsx);
axis([-70*s2 70*s2 0 1.1])
xlabel('x (mm)')
ylabel('Intensity')

%figure 5 
figure5 = figure(5);
set(figure(5), 'Position', [0 0 1500 800])
axes1 = subplot(1,3,[1 2]);
quiver(xs*1e3,ys*1e3,Erealx,Erealy)
xlabel('x (mm)')
ylabel('y (mm)')

axes2 = subplot(1,3,3);
surf(xs*1e3,ys*1e3,Ephase),shading interp,colormap('jet'),colorbar;
view(0,90),axis tight equal,
caxis([-pi pi])

%saving the figures
%
if near == true
    d = "5um ";
else
    d = "50mm ";
end

f0=f*10^-12;

%naming the figures
title1= ""+d+f0+"THz Ex.png";
title2= ""+d+f0+"THz Ey.png";
title3= ""+d+f0+"THz Ez.png";
title4= ""+d+f0+"THz Etot.png";
title5= ""+d+f0+"THz Vector.png";

saveas(figure1, title1)
saveas(figure2, title2)
saveas(figure3, title3)
saveas(figure4, title4)
saveas(figure5, title5)
%}

%saving the complex variables (Efield strength of real and imaginary parts
%for each component
%{
save('Ex.mat','Erawx');
save('Ey.mat','Erawy');
save('Ez.mat','Erawz');
%}

%unused code:
%
%attemt to create a vector field of x and y components
%figure 5

%reduce data to 28x28 from 281x281 for better E vector map 
%{
Eredx=Erealx(1:280,1:280);
Eredy=Erealy(1:280,1:280);
Eshapex=reshape(Eredx,10,10,784);
Earrowx=reshape(mean(mean(Eshapex)),[28,28]);
Eshapey=reshape(Eredy,10,10,784);
Earrowy=reshape(mean(mean(Eshapey)),[28,28]);

xq=(-70:5:65);
yq=(-70:5:65);
%}

% pakeisti spalvu palete i poliarine
%{
%attempt to create a better colormap for phase map
%where theta=0 and theta= 2pi have the same colour
red=(horzcat(linspace(0,1,64), linspace(1,0,64)))';
blue=(horzcat(linspace(1,0,64), linspace(0,1,64)))';
green=(horzcat(linspace(0,0,64), linspace(0,0,64)))';
polarmap = [red, blue, green];
%}
%}
