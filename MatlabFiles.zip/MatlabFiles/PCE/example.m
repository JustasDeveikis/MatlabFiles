[x,y] = meshgrid(0:.5:2,-1:.2:1);
z = x .* exp(-x.^2 - y.^2);
[u,v,w] = surfnorm(x,y,z);
z = zeros(size(x));
quiver3(x,y,z,u,v,w);
view([0 90])